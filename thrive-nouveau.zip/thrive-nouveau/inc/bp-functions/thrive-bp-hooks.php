<?php
/**
 * Custom BuddyPress Hooks
 * Since 3.0.6
 */
add_action('bp_before_activity_entry', 'thrive_apply_bp_current_component');

/**
 * Apply bp current component to pages that are using buddypress activity shortcode.
 * @return void.
 */
function thrive_apply_bp_current_component() {
	if ( function_exists('buddypress') ) {
		if ( false === bp_current_component() ) {
			buddypress()->current_component = 'activity';
		}
	}
}

add_filter('bp_core_get_js_strings', 'thrive_apply_bp_js_strings');

/**
 * Applies the missing strings and object parameters when in pages and post.
 * @return void
 */
function thrive_apply_bp_js_strings( $params ) {
	
	if ( false !== bp_current_component() ) {
		return $params;
	}

	$activity_params = array(
		'user_id'     => bp_loggedin_user_id(),
		'object'      => 'user',
		'backcompat'  => (bool) has_action( 'bp_activity_post_form_options' ),
		'post_nonce'  => wp_create_nonce( 'post_update', '_wpnonce_post_update' ),
	);

	$user_displayname = bp_get_loggedin_user_fullname();

	if ( buddypress()->avatar->show_avatars ) {

		$width  = bp_core_avatar_thumb_width();
		$height = bp_core_avatar_thumb_height();

		$activity_params = array_merge( $activity_params, array(
			'avatar_url'    => bp_get_loggedin_user_avatar( array(
				'width'  => $width,
				'height' => $height,
				'html'   => false,
			) ),
			'avatar_width'  => $width,
			'avatar_height' => $height,
			'user_domain'   => bp_loggedin_user_domain(),
			'avatar_alt'    => sprintf(
				/* translators: %s = member name */
				__( 'Profile photo of %s', 'thrive' ),
				$user_displayname
			),
		) );
	}

	$activity_buttons = apply_filters( 'bp_nouveau_activity_buttons', array() );

	if ( ! empty( $activity_buttons ) ) {

		$activity_params['buttons'] = bp_sort_by_key( $activity_buttons, 'order', 'num' );
		// Enqueue Buttons scripts and styles
		foreach ( $activity_params['buttons'] as $key_button => $buttons ) {
			if ( empty( $buttons['handle'] ) ) {
				continue;
			}
			if ( wp_style_is( $buttons['handle'], 'registered' ) ) {
				wp_enqueue_style( $buttons['handle'] );
			}
			if ( wp_script_is( $buttons['handle'], 'registered' ) ) {
				wp_enqueue_script( $buttons['handle'] );
			}
			unset( $activity_params['buttons'][ $key_button ]['handle'] );
		}
	}
	
	$activity_strings = array(
		'whatsnewPlaceholder' => sprintf( __( "What's new, %s?", 'buddypress' ), bp_get_user_firstname( $user_displayname ) ),
		'whatsnewLabel'       => __( 'Post what\'s new', 'buddypress' ),
		'whatsnewpostinLabel' => __( 'Post in', 'buddypress' ),
		'postUpdateButton'    => __( 'Post Update', 'buddypress' ),
		'cancelButton'        => __( 'Cancel', 'buddypress' ),
	);
	if ( bp_is_group() ) {
		$activity_params = array_merge(
			$activity_params,
			array(
				'object'  => 'group',
				'item_id' => bp_get_current_group_id(),
			)
		);
	}
	$params['activity'] = array(
		'params'  => $activity_params,
		'strings' => $activity_strings,
	);
	return $params;
}